/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exerc2_aula3;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;
public class Exerc2_aula3 {

    public static void main(String[] args) {
        //mostrar o maior arquivo do vetor
        //soma dos tamanhos de todos os arquivos do vetor
        //quantidade de arquivos de mesmo tipo no vetor
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Informe o número de arquivos que deseja criar: ");
        int n_repeticoes = sc.nextInt();
        
        //verifica se o número de arquivos criados é menor que 100 e positivo
        while(n_repeticoes <=0 || n_repeticoes > 100){
            System.out.println("Valor inválido. Tente novamente: ");
            n_repeticoes = sc.nextInt();
        }
        Documento[] documentos = new Documento[n_repeticoes];
        
        //loop para criar os arquivos
        for (int i = 0; i < n_repeticoes; i++){
            documentos[i] = new Documento("", "", 0);
            documentos[i].ler_dados();
            documentos[i].mostrar_dados();
            System.out.println("-----------//-----------");
        }
        
        
        Documento objAux = new Documento("", "", 0);
        objAux.maiorDocumento(documentos);
        
        int somar = objAux.somaTamanhoDocumentos(documentos);
        System.out.println("-----------//-----------");
        System.out.println("Soma dos tamanhos dos arquivos: " + somar);

        System.out.println("Digite o formato de arquivo: ");
        String formatoEscolhido = sc.nextLine();
        int quantidadeDocsTipo = objAux.arquivosMesmaExtensao(documentos, formatoEscolhido);
        System.out.println("Formato Escolhido: " + formatoEscolhido);
        System.out.println("Quantidade de documentos: " + quantidadeDocsTipo);
    }
}
