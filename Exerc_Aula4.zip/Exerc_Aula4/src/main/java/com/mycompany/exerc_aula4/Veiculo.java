/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exerc_aula4;

/**
 *
 * @author ADMIN
 */
public class Veiculo {
    //adicionar atributo de valor da venda
    private String placa;
    private String modelo;
    private String fabricante;
    private int km;
    private int anofab;
    private float valorVenda;
    
    //construtor com valores default
    public Veiculo(){
        placa = "Desconhecido";
        modelo = "Desconhecido";
        fabricante = "Desconhecido";
        km = 0;
        anofab = 0;
        valorVenda = 0;
    }
    
    public int aumentarKm (int addKm){
        km = addKm+km;
        return km;
    }
    
    /*
    void aumentarKm(int addKm){
        int kmExtra = addKm + km;
    }
    */
    
    //MÉTODOS GET
    public String getPlaca(){
        return placa;
    }
    
    public String getModelo(){
        return modelo;
    }
    
    public String getFabricante(){
        return fabricante;
    }
    
    public int getKm(){
        return km;
    }
    
    public int getAnofab(){
        return anofab;
    }
    
    public float getValorVenda(){
        return valorVenda;
    }
    
    //MÉTODOS SET
    public void setPlaca(String placa){
        this.placa = placa;
    }
    
    public void setModelo(String modelo){
        this.modelo = modelo;
    }
    
    public void setFabricante(String fabricante){
        this.fabricante = fabricante;
    }
    
    public void setKm(int km){
        this.km = km;
    }
    
    public void setAnofab(int anofab){
        this.anofab = anofab;
    }
    
    public void setValorVenda(float valorVenda){
        this.valorVenda = valorVenda;
    }
    
    
    int veiculosMesmoModelo(Veiculo[] vetorVeiculos, String modeloVeiculo){
        int total = 0;
        
        //loop que percorre o vetor com os arquivos criados
        for(int i = 0; i < vetorVeiculos.length; i++){
            //se a extensao do elemento for igual à extensão do arquivo
            if(vetorVeiculos[i].modelo.equals(modeloVeiculo)){
                //incrementa no número total de arquivos
                total = total + 1;
            }
        }

        return total;
    }
    
    void maiorVenda(Veiculo[] vetorVeiculos){
        //maiorV recebe o vetor contendo todos os veiculos criados
        Veiculo maiorV = vetorVeiculos[0];
        
        //loop para percorrer todos os vetores
        for(int i = 0; i < vetorVeiculos.length - 1; i++){
            //se o proximo elemento do vetor tiver um valor de venda maior que o elemento atual
            if(vetorVeiculos[i + 1].valorVenda > vetorVeiculos[i].valorVenda){
                //maiorV recebe o próximo vetor
                maiorV = vetorVeiculos[i + 1];
            }
        }

        //placa, modelo, fabricante, km, anofab e valorVenda
        System.out.println("Veículo mais caro: ");
        System.out.println("Placa: " + maiorV.placa);
        System.out.println("Modelo: " + maiorV.modelo);
        System.out.println("Fabricante: " + maiorV.fabricante);
        System.out.println("Km: " + maiorV.km);
        System.out.println("AnoFab: " + maiorV.anofab);
        System.out.println("Valor: " + maiorV.valorVenda); 
    }
    
    void menorVenda(Veiculo[] vetorVeiculos){
        //menorV recebe o vetor contendo todos os veiculos criados
        Veiculo menorV = vetorVeiculos[0];
        
        //loop para percorrer todos os vetores
        for(int i = 0; i < vetorVeiculos.length - 1; i++){
            //se o proximo elemento do vetor tiver um valor de venda menor que o elemento atual
            if(vetorVeiculos[i + 1].valorVenda < vetorVeiculos[i].valorVenda){
                //menorV recebe o próximo vetor
                menorV = vetorVeiculos[i + 1];
            }
        }

        //placa, modelo, fabricante, km, anofab e valorVenda
        System.out.println("Veículo mais barato: ");
        System.out.println("Placa: " + menorV.placa);
        System.out.println("Modelo: " + menorV.modelo);
        System.out.println("Fabricante: " + menorV.fabricante);
        System.out.println("Km: " + menorV.km);
        System.out.println("AnoFab: " + menorV.anofab);
        System.out.println("Valor: " + menorV.valorVenda); 
    }
    
    void maiorKm(Veiculo[] vetorVeiculos){
        //maiorKm recebe o vetor contendo todos os veiculos criados
        Veiculo maiorKm = vetorVeiculos[0];
        
        //loop para percorrer todos os vetores
        for(int i = 0; i < vetorVeiculos.length - 1; i++){
            //se o proximo elemento do vetor tiver um km maior que o elemento atual
            if(vetorVeiculos[i + 1].km > vetorVeiculos[i].km){
                //maiorKm recebe o próximo vetor
                maiorKm = vetorVeiculos[i + 1];
            }
        }

        //placa, modelo, fabricante, km, anofab e valorVenda
        System.out.println("Maior quilometragem: ");
        System.out.println("Placa: " + maiorKm.placa);
        System.out.println("Modelo: " + maiorKm.modelo);
        System.out.println("Fabricante: " + maiorKm.fabricante);
        System.out.println("Km: " + maiorKm.km);
        System.out.println("AnoFab: " + maiorKm.anofab);
        System.out.println("Valor: " + maiorKm.valorVenda); 
    }
    
    void menorKm(Veiculo[] vetorVeiculos){
        //menorKm recebe o vetor contendo todos os veiculos criados
        Veiculo menorKm = vetorVeiculos[0];
        
        //loop para percorrer todos os vetores
        for(int i = 0; i < vetorVeiculos.length - 1; i++){
            //se o proximo elemento do vetor tiver um km menor que o elemento atual
            if(vetorVeiculos[i + 1].km < vetorVeiculos[i].km){
                //menorKm recebe o próximo vetor
                menorKm = vetorVeiculos[i + 1];
            }
        }

        //placa, modelo, fabricante, km, anofab e valorVenda
        System.out.println("Menor quilometragem: ");
        System.out.println("Placa: " + menorKm.placa);
        System.out.println("Modelo: " + menorKm.modelo);
        System.out.println("Fabricante: " + menorKm.fabricante);
        System.out.println("Km: " + menorKm.km);
        System.out.println("AnoFab: " + menorKm.anofab);
        System.out.println("Valor: " + menorKm.valorVenda); 
    }
    
}
