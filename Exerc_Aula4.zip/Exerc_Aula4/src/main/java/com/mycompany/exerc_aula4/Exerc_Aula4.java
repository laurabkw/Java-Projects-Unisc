/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exerc_aula4;

import java.util.Scanner;
import java.util.Arrays;

/**
 *
 * @author ADMIN
 */
public class Exerc_Aula4 {

    public static void main(String[] args) {
        //atributos privados
        //criar métodos para set e get para cada atributo
        //excluir def_dados e mostrar_dados
        //criar construtor
        //inicializar int com 0 e strings com desconhecido
        int numVeiculos = 3;
        Veiculo[] veiculos = new Veiculo[numVeiculos];
        
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < numVeiculos; i++){
            veiculos[i] = new Veiculo();
            System.out.println("Placa: ");
            String placa = sc.next();
            while(placa.equals("Desconhecido")){
                System.out.println("Valor inválido. Tente novamente: ");
                placa = sc.next();
            }
            veiculos[i].setPlaca(placa);
            
            System.out.println("Modelo: ");
            String modelo = sc.next();
            while(modelo.equals("Desconhecido")){
                System.out.println("Valor inválido. Tente novamente: ");
                modelo = sc.next();
            }
            veiculos[i].setModelo(modelo);
            
            //fazer validações se os campos de string não são vazios
            System.out.println("Fabricante: ");
            String fabricante = sc.next();
            while(fabricante.equals("Desconhecido")){
                System.out.println("Valor inválido. Tente novamente: ");
                fabricante = sc.next();
            }
            veiculos[i].setFabricante(fabricante);
            
            System.out.println("Quilometragem: ");
            int km = sc.nextInt();
            while(km <= 0){
                System.out.println("Valor inválido. Tente novamente: ");
                km = sc.nextInt();
            }
            veiculos[i].setKm(km);
            
            System.out.println("Ano de Fabricação: ");
            int anofab = sc.nextInt();
            while((anofab < 1950) || (anofab > 2024)){
                System.out.println("Valor inválido. Tente novamente: ");
                anofab = sc.nextInt();
            }
            veiculos[i].setAnofab(anofab);
            
            System.out.println("Valor do Veículo: ");
            float valorVenda = sc.nextFloat();
            while(valorVenda <= 0){
                System.out.println("Valor inválido. Tente novamente: ");
                valorVenda = sc.nextFloat();
            }
            veiculos[i].setValorVenda(valorVenda);
            
            /*
            //teste array recebe dados
            System.out.println("Placa: " + veiculos[i].getPlaca());
            System.out.println("Modelo: " + veiculos[i].getModelo());
            System.out.println("Fabricante: " + veiculos[i].getFabricante());
            System.out.println("Quilometragem" + veiculos[i].getKm());
            System.out.println("Ano de Fabricação" + veiculos[i].getAnofab());
            */
        }
        int novaKm = 0;
        System.out.println("Insira a placa que deseja procurar: ");
        String procurarVeiculo = sc.next();
        System.out.println("Insira valor que deseja incrementar: ");
        int addKm = sc.nextInt();
        for(int i = 0; i < numVeiculos; i++){
            if (procurarVeiculo.equals(veiculos[i].getPlaca())){
                novaKm = veiculos[i].aumentarKm(addKm);
                procurarVeiculo = veiculos[i].getPlaca();
            }
        }
        System.out.println("Placa do Veículo: " + procurarVeiculo);
        System.out.println("Nova Quilometragem: " + novaKm);
        System.out.println("\n");
        
        Veiculo objAux = new Veiculo();  
        objAux.maiorVenda(veiculos);
        System.out.println("\n");
        objAux.menorVenda(veiculos);
        System.out.println("\n");
        objAux.maiorKm(veiculos);
        System.out.println("\n");
        objAux.menorKm(veiculos);
    }
}
