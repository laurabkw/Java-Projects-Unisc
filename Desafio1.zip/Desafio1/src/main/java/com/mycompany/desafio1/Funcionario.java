/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.desafio1;

/**
 *
 * @author ADMIN
 */
import java.util.ArrayList;
import java.util.List;
public class Funcionario {
    private int idFuncionario;
    private String nome;
    private List<Integer> idOcorrencias = new ArrayList<>();
    private List<Integer> idOcorrenciasRecebidas = new ArrayList<>();
    private List<Integer> idOcorrenciasAtendidas = new ArrayList<>();
    private List<Integer> idOcorrenciasAcompanhadas = new ArrayList<>();
    
    public Funcionario(int idFuncionario, String nome){
        this.idFuncionario = idFuncionario;
        this.nome = nome;
    }
    
    public int getIdFuncionario(){
        return idFuncionario;
    }
    
    public String getNome(){
        return nome;
    }
    
    public List<Integer> getIdOcorrencias(){
        return idOcorrencias;
    }
    
    public List<Integer> getIdOcorrenciasRecebidas(){
        return idOcorrenciasRecebidas;
    }
    
    public List<Integer> getIdOcorrenciasAtendidas(){
        return idOcorrenciasAtendidas;
    }
    
    public List<Integer> getIdOcorrenciasAcompanhadas(){
        return idOcorrenciasAcompanhadas;
    }

    public void setIdFuncionario(int idFuncionario){
        if(idFuncionario <= 0 || idFuncionario < 999){
            this.idFuncionario = 0;
        }
        else{
            this.idFuncionario = idFuncionario;
        }
    }
    
    public void adicionarIdOcorrencia(int idOcorrencia){
        if(idOcorrencia > 0){
            this.idOcorrencias.add(idOcorrencia);
        }
    }
    
    public void setNome(String nome){
        if(nome.equals("") || nome.isBlank()){
            this.nome = "";
        }
        else{
            this.nome = nome;
        }
    }
    
    //métodos para adicionar IDs às listas corretas
    public void adicionarOcorrenciaRecebida(int idOcorrencia){
        idOcorrenciasRecebidas.add(idOcorrencia);
    }
    
    public void adicionarOcorrenciaAtendida(int idOcorrencia){
        if (!idOcorrenciasAtendidas.contains(idOcorrencia)) {
            idOcorrenciasAtendidas.add(idOcorrencia);
        }
    }
    
    public void adicionarOcorrenciaAcompanhada(int idOcorrencia){
        idOcorrenciasAcompanhadas.add(idOcorrencia);
    }
}