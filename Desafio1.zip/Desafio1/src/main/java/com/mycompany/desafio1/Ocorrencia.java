/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.desafio1;

/**
 *
 * @author ADMIN
 */

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.Random;
//fazer um construtor com as informações da ocorrencia e outro contendo quais funcionarios interagiram com aquela ocorrencia
public class Ocorrencia {
    private int idOcorrencia;
    private LocalDate data;
    private String local;
    private String tipo;
    private int gravidade;
    private String nomeFuncionarioRecebeu;
    private String nomeFuncionarioAtendeu;
    private String nomeFuncionarioAcompanhou;
    
    //construtor vazio
    public Ocorrencia(){
        
    }
    
    //infos construtor 1
    public Ocorrencia(int idOcorrencia, LocalDate data, String local, String tipo, int gravidade){
        this.idOcorrencia = idOcorrencia;
        this.data = data;
        this.local = local;
        this.tipo = tipo;
        this.gravidade = gravidade;
    }
    
    //infos construtor 2
    public Ocorrencia(String nomeFuncionarioRecebeu, String nomeFuncionarioAtendeu, String nomeFuncionarioAcompanhou){
        this.nomeFuncionarioAtendeu = nomeFuncionarioAtendeu;
        this.nomeFuncionarioRecebeu = nomeFuncionarioRecebeu;
        this.nomeFuncionarioAcompanhou = nomeFuncionarioAcompanhou;
    }
    
    public int getIdOcorrencia(){
        return idOcorrencia;
    }
    
    public LocalDate getData(){
        return data;
    }
    
    public String getLocal(){
        return local;
    }
    
    public String getTipo(){
        return tipo;
    }
    
    public int getGravidade(){
        return gravidade;
    }
    
    public String getNomeFuncionarioAtendeu(){
        return nomeFuncionarioAtendeu;
    }
    
    public String getNomeFuncionarioRecebeu(){
        return nomeFuncionarioRecebeu;
    }
    
    public String getNomeFuncionarioAcompanhou(){
        return nomeFuncionarioAcompanhou;
    }
    
    public void setIdOcorrencia(int idOcorrencia){
        if(idOcorrencia <= 0 || idOcorrencia < 999){
            this.idOcorrencia = 0;
        }
        else{
            this.idOcorrencia = idOcorrencia;
        }
    }
    
    public void setData(LocalDate data){
        if(data==null){
            throw new IllegalArgumentException("Data não pode ser nula.");
        }
        if(data.getYear()!=2025){
            throw new IllegalArgumentException("Data Inválida. Apenas datas de 2025 são aceitas.");
        }
        this.data=data;
    }
    
    public void setLocal(String local){
        if(local.equals("") || local.isBlank()){
            this.local = "";
        }
        else{
            this.local = local;
        }
    }
    
    public void setTipo(String tipo){
        if(tipo.equals("") || tipo.isBlank()){
            this.tipo = "";
        }
        else{
            this.tipo = tipo;
        }
    }
    
    public void setGravidade(int gravidade){
        if(gravidade <= 0 || gravidade > 10){
            this.gravidade = 1;
        }
        else{
            this.gravidade = gravidade;
        }
    }
    
    //métodos só são chamados se o nome do funcionário não for nulo, somente se ele tiver alguma relação com a ocorrência
    public void setNomeFuncionarioRecebeu(String nome){
        if(nome!=null){
            this.nomeFuncionarioRecebeu=nome;
        }
    }
    
    public void setNomeFuncionarioAtendeu(String nome){
        if(nome!=null){
            this.nomeFuncionarioRecebeu=nome;
        }
    }
    
    public void setNomeFuncionarioAcompanhou(String nome){
        if(nome!=null){
            this.nomeFuncionarioRecebeu=nome;
        }
    }
}
