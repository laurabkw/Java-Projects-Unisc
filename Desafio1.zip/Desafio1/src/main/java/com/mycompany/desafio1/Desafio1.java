/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.desafio1;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;
import java.util.Random;
import java.time.LocalDate;
import java.time.Month;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class Desafio1 {

    public static void main(String[] args) {
        //Desafio 1 - Java
        //Feito por: Laura Beatriz Kappel Waechter
        //Explicação do Código: https://drive.google.com/file/d/154WcF_GZVkOY9SQCQfzN6CHIO633rC80/view?usp=sharing
        //Execução: https://drive.google.com/file/d/1E6ezkbR36VSEaZO2w4mGLimzX5xX2BQK/view?usp=sharing
        
        Scanner sc = new Scanner(System.in);
        Random random = new Random();
        
        //nomes de funcionários
        String[] nomes = {"Jorge", "Carlos", "Mariana", "Júlia", "Felipe", "Ana", "Sérgio", "Gabriel", "Henrique", "Matheus", "Daniela", "Mônica", "Maurício", "Regina", "Gabriela", "Carla", "Débora", "Márcio", "Camila"};
        
        //tipos de ocorrências
        String[] tipos = {"Disparo de Alarme","Movimentação Suspeita","Falha no Sistema de Alarme","Sensor de Presença Ativado","Roubo/Furto","Incêndio","Vandalismo","Queda de Energia","Contaminação","Falha no Sistema de Vigilância", "Tentativa de Invasão"};
        
        //locais onde ocorrências podem acontecer
        String [] locais = {"Empresa Solutions","Loja Shopping","Hospital Vida","Escola São Pedro","Depósito Zona Norte", "Agência Bancária Bank","Supermercado Econômico","Posto de Combustível 24h","Laboratório Lab"};
        
        //número de funcionários e ocorrências que serão gerados
        int criarFuncionarios = 20;
        int criarOcorrencias = 15;
        
        //criando novo objeto
        Funcionario[] funcionarios = new Funcionario[criarFuncionarios]; //cria array fixo
        List<Ocorrencia> ocorrencias = new ArrayList<>(); //cria lista dinâmica
        
        //repetição para criaçao de funcionários
        for(int i = 0; i < criarFuncionarios; i++){
            // Gera um ID aleatório para o funcionário
            int idFuncLoop = random.nextInt(9000) + 1000;  // ID aleatório entre 1000 e 9999

            // Escolhe um nome aleatório do array de nomes
            String nomeFuncLoop = nomes[random.nextInt(nomes.length)];

            // Cria o novo funcionário com ID e nome
            funcionarios[i] = new Funcionario(idFuncLoop, nomeFuncLoop);
        }
        
        
        //repetição para criar ocorrências
        for(int i=0;i<criarOcorrencias;i++){
            Ocorrencia ocorrencia = new Ocorrencia(); //cria objeto
            
            int gerarIdOcorrencia = random.nextInt(9000)+1000; //gera um id aleatório para ocorrência
            
            //gerar data com mês e dia aleatórios, ano sempre será 2025
            int ano = 2025; //ano fixo
            int mes = random.nextInt(12)+1; //entre 1 e 12, soma 1 para que 0 não seja escolhido
            YearMonth anoMes = YearMonth.of(ano, mes); //descobre quantos dias tem no mês escolhido
            int diasNoMes = anoMes.lengthOfMonth(); //descobre quantos dias tem no mês escolhido
            int dia = random.nextInt(diasNoMes)+1; //gera dia aleatório dentro dos dias disponíveis no mês
            
            //gerar ocorrencias - populando cada atributo com valores aleatórios
            LocalDate dataAleatoria = LocalDate.of(ano, mes, dia);
            ocorrencia.setIdOcorrencia(gerarIdOcorrencia);
            ocorrencia.setLocal(locais[random.nextInt(locais.length)]);
            ocorrencia.setData(dataAleatoria);
            ocorrencia.setTipo(tipos[random.nextInt(tipos.length)]);
            ocorrencia.setGravidade(random.nextInt(10) + 1);
            
            //escolhe funcionários para receber, atender ou acompanhar uma ocorrência
            Funcionario funcRecebeu = funcionarios[random.nextInt(criarFuncionarios)];
            Funcionario funcAtendeu = funcionarios[random.nextInt(criarFuncionarios)];
            Funcionario funcAcompanhou = funcionarios[random.nextInt(criarFuncionarios)];
            
            //adiciona o nome do funcionário à ocorrência de acordo com sua relação, recebeu, atendeu ou acompanhou
            ocorrencia.setNomeFuncionarioRecebeu(funcRecebeu.getNome());
            ocorrencia.setNomeFuncionarioAtendeu(funcAtendeu.getNome());
            ocorrencia.setNomeFuncionarioAcompanhou(funcAcompanhou.getNome());
            
            //atualiza funcionário
            funcRecebeu.adicionarOcorrenciaRecebida(gerarIdOcorrencia); //associa o ID da ocorrência ao funcionário que recebeu
            funcRecebeu.adicionarIdOcorrencia(gerarIdOcorrencia); 
            funcAtendeu.adicionarOcorrenciaAtendida(gerarIdOcorrencia); //associa o ID da ocorrência ao funcionário quq atendeu
            funcAtendeu.adicionarIdOcorrencia(gerarIdOcorrencia);
            funcAcompanhou.adicionarOcorrenciaAcompanhada(gerarIdOcorrencia); //associa o ID da ocorrência ao funcionário que acompanhou
            funcAcompanhou.adicionarIdOcorrencia(gerarIdOcorrencia);
            
            //adiciona a nova ocorrência à lista
            ocorrencias.add(ocorrencia);
            
            //exibe informações da ocorrência criada
            System.out.println("Ocorrência criada:");
            System.out.println("ID Ocorrência: " + gerarIdOcorrencia);
            System.out.println("Data: " + dataAleatoria);
            System.out.println("Local: " + ocorrencia.getLocal());
            System.out.println("Tipo: " + ocorrencia.getTipo());
            System.out.println("Gravidade: " + ocorrencia.getGravidade());
            
            //mostra o nome do funcionário relacionado à ocorrência
            System.out.println("Funcionário que Recebeu: " + funcRecebeu.getNome());
            System.out.println("Funcionário que Atendeu: " + funcAtendeu.getNome());
            System.out.println("Funcionário que Acompanhou: " + funcAcompanhou.getNome());
            System.out.println("\n----------------------------------------\n");
        }
        
        for(int i = 0; i<criarFuncionarios;i++){
            //exibe informações do funcionário criado
            System.out.println("Funcionário criado:");
            System.out.println("ID: " + funcionarios[i].getIdFuncionario());
            System.out.println("Nome: " + funcionarios[i].getNome());
            
            //verifica se o funcionário recebeu a ocorrência
            if(!funcionarios[i].getIdOcorrenciasRecebidas().isEmpty()){
                System.out.println("Recebeu Ocorrência: SIM | ID Ocorrência(s): " + funcionarios[i].getIdOcorrenciasRecebidas());
            }
            else{
                System.out.println("Recebeu Ocorrência: NÃO");
            }
            
            //verifica se o funcionário atendeu a ocorrência
            if(!funcionarios[i].getIdOcorrenciasAtendidas().isEmpty()){
                System.out.println("Recebeu Ocorrência: SIM | ID Ocorrência(s): " + funcionarios[i].getIdOcorrenciasAtendidas());
            }
            else{
                System.out.println("Recebeu Ocorrência: NÃO");
            }
            
            //verifica se o funcionário acompanhou a ocorrência
            if(!funcionarios[i].getIdOcorrenciasAcompanhadas().isEmpty()){
                System.out.println("Recebeu Ocorrência: SIM | ID Ocorrência(s): " + funcionarios[i].getIdOcorrenciasAcompanhadas());
            }
            else{
                System.out.println("Recebeu Ocorrência: NÃO");
            }
            
            System.out.println("\n----------------------------------------\n");
        }
        
        while(true){
            //menu de opções
            System.out.println("###---Menu Principal---###");
            System.out.println("|------------------------|");
            System.out.println("|1- Nova ocorrência      |");
            System.out.println("|2- Novo funcionário     |");
            System.out.println("|3- Relatório            |");
            System.out.println("|4- Sair                 |");
            System.out.println("|------------------------|");
            System.out.println("Digite uma opção: ");   
            
            int opcao = sc.nextInt();
            
            switch(opcao){
                case 1:
                    System.out.println("Cadastrar Nova Ocorrência: ");
                    System.out.println("Data (dd/MM/yyyy): ");
                    sc.nextLine(); //adicionado para consumir o \n pendente
                    String dataStr = sc.nextLine();
                    LocalDate dataOcorrencia = null; //inicializa a data vazia
                    try{
                        //verifica se a data está em um formato válido
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                        dataOcorrencia = LocalDate.parse(dataStr, formatter);
                    }catch (DateTimeParseException e){
                        //se não estiver, mensagem de erro
                        System.out.println("Data inválida. Ocorrência não registrada.");
                        break;
                    }
                    
                    System.out.println("Local: ");
                    String local = sc.nextLine();
                    
                    System.out.println("Tipo: ");
                    String tipo = sc.nextLine();
                    
                    System.out.println("Gravidade (1 a 10): ");
                    int gravidade = sc.nextInt();
                    sc.nextLine(); //limpa quebra de linha após nextInt
                    
                    System.out.println("Nome do funcionário que atendeu: ");
                    String nomeFuncionario = sc.nextLine();
                    
                    Funcionario funcionarioEncontrado = null;
                    
                    //verifica, dentro do array funcionarios, se existe um com o nome digitado
                    for (Funcionario f : funcionarios) {
                        //compara o nome contido no array com o digitado, ignora diferenças de maiúsculas e minúsculas
                        if (f.getNome().equalsIgnoreCase(nomeFuncionario)) {
                            //funcionário encontrado
                            funcionarioEncontrado = f;
                            break;
                        }
                    }
                    
                    //se o nome digitado não existir
                    if (funcionarioEncontrado == null) {
                        System.out.println("Funcionário não encontrado. Ocorrência não registrada.");
                        break;
                    }

                    //cria e preenche nova ocorrência
                    int novoIdOcorrencia = random.nextInt(9000) + 1000;
                    Ocorrencia nova = new Ocorrencia();
                    nova.setIdOcorrencia(novoIdOcorrencia);
                    nova.setData(dataOcorrencia);
                    nova.setLocal(local);
                    nova.setTipo(tipo);
                    nova.setGravidade(gravidade);
                    nova.setNomeFuncionarioAtendeu(nomeFuncionario);

                    //adiciona ocorrência à lista
                    ocorrencias.add(nova);

                    //atualiza dados de funcionário
                    funcionarioEncontrado.adicionarOcorrenciaAtendida(novoIdOcorrencia);
                    funcionarioEncontrado.adicionarIdOcorrencia(novoIdOcorrencia);
                    
                    //mostra o id da nova ocorrência
                    System.out.println("Ocorrência registrada com sucesso. ID: " + novoIdOcorrencia);
                    break;
                    
                case 2:
                    //defina o tamanho máximo do array de funcionários
                    final int MAX_FUNCIONARIOS = 100; //pode ser ajustado conforme necessário
                    Funcionario[] funcLimite = new Funcionario[MAX_FUNCIONARIOS];
                    int numFuncionarios = 0; //contador para o número de funcionários cadastrados

                    System.out.println("Cadastrar Novo Funcionário:");
                    sc.nextLine(); // Limpar buffer
                    System.out.println("Nome: ");
                    String nomeNovoFuncionario = sc.nextLine();
                    
                    //gera um id aleatório para o novo funcionário
                    int novoIdFuncionario = random.nextInt(9000) + 1000;
                    
                    //verifica se há ocorrências cadastradas
                    if (ocorrencias.isEmpty()) {
                        System.out.println("Nenhuma ocorrência cadastrada. Cadastre uma ocorrência primeiro.");
                        //break;
                    }
                    
                    //exibir ocorrências disponíveis
                    System.out.println("Ocorrências disponíveis:");
                    for (Ocorrencia o : ocorrencias) {
                        //mostra o id e o tipo das ocorrências
                        System.out.println("- ID: " + o.getIdOcorrencia() + " | Tipo: " + o.getTipo());
                    }

                    //pede para o usuário inserir o id da ocorrência que o novo funcionário vai pegar
                    System.out.println("Digite o ID da ocorrência que o funcionário está relacionado:");
                    int idOcorrenciaRelacionada = sc.nextInt();
                    sc.nextLine(); // Limpar quebra de linha

                    //busca ocorrência pelo id
                    Ocorrencia ocorrenciaRelacionada = null;
                    for (Ocorrencia o : ocorrencias) {
                        //se o id digitado estiver na lista
                        if (o.getIdOcorrencia() == idOcorrenciaRelacionada) {
                            //recebe o id da ocorrência digitada
                            ocorrenciaRelacionada = o;
                            break;
                        }
                    }

                    //caso não ache
                    if (ocorrenciaRelacionada == null) {
                        System.out.println("ID de ocorrência não encontrado. Cadastro cancelado.");
                        break;
                    }

                    //pergunta o tipo de relação do funcionário com a ocorrência
                    System.out.println("O funcionário:");
                    System.out.println("1 - Recebeu");
                    System.out.println("2 - Atendeu");
                    System.out.println("3 - Acompanhou");
                    int opcaoRelacao = sc.nextInt();
                    
                    //insere o novo funcionario
                    Funcionario novoFuncionario = new Funcionario(novoIdFuncionario, nomeNovoFuncionario);

                    //relaciona a ocorrência ao funcionário
                    novoFuncionario.adicionarIdOcorrencia(idOcorrenciaRelacionada);
                    
                    //opções para escolher se o novo funcionário atendeu, recebeu ou acompanhou um ocorrência
                    switch (opcaoRelacao) {
                        case 1:
                            novoFuncionario.adicionarOcorrenciaRecebida(idOcorrenciaRelacionada);
                            ocorrenciaRelacionada.setNomeFuncionarioRecebeu(nomeNovoFuncionario);
                            break;
                        case 2:
                            novoFuncionario.adicionarOcorrenciaAtendida(idOcorrenciaRelacionada);
                            ocorrenciaRelacionada.setNomeFuncionarioAtendeu(nomeNovoFuncionario);
                            break;
                        case 3:
                            novoFuncionario.adicionarOcorrenciaAcompanhada(idOcorrenciaRelacionada);
                            ocorrenciaRelacionada.setNomeFuncionarioAcompanhou(nomeNovoFuncionario);
                            break;
                        default:
                            System.out.println("Opção inválida. Funcionário não cadastrado.");
                            break;
                    }

                    //adiciona o novo funcionário ao array, se houver espaço
                    if (numFuncionarios < MAX_FUNCIONARIOS) {
                        funcionarios[numFuncionarios] = novoFuncionario; //armazena o novo funcionário no próximo índice
                        numFuncionarios++; //incrementa o contador de funcionários cadastrados
                        System.out.println("Funcionário cadastrado com sucesso:");
                        System.out.println("ID: " + novoIdFuncionario);
                        System.out.println("Nome: " + nomeNovoFuncionario);
                    } else {
                        //se não houver espaços
                        System.out.println("Limite máximo de funcionários atingido.");
                    }

                    break;
                
                case 3:
                    boolean subMenuRelatorio = true;
                    while(subMenuRelatorio){
                        System.out.println("###---Filtrar por---###");
                        System.out.println("|---------------------|");
                        System.out.println("|1- Funcionário       |");
                        System.out.println("|2- Mês               |");
                        System.out.println("|3- Local             |");
                        System.out.println("|4- Tipo              |");
                        System.out.println("|5- Gravidade         |");
                        System.out.println("|6- Voltar            |");
                        System.out.println("|---------------------|");
                        System.out.println("Digite uma opção: ");
                        
                        int filtro = sc.nextInt();
                        switch(filtro){
                            case 1: 
                                sc.nextLine(); //limpar buffer
                                System.out.println("Digite o nome do funcionário para buscar ocorrências relacionadas:");
                                String nomeBusca = sc.nextLine();

                                boolean encontrouFunc = false;

                                //percorre todas as ocorrências cadastradas
                                for (Ocorrencia o : ocorrencias) {
                                    //verifica se o funcionário está relacionado a esta ocorrência de alguma forma
                                    boolean funcionarioRelacionado = false;

                                    if (o.getNomeFuncionarioRecebeu() != null && o.getNomeFuncionarioRecebeu().equalsIgnoreCase(nomeBusca)) {
                                        funcionarioRelacionado = true;
                                    } 
                                    if (o.getNomeFuncionarioAtendeu() != null && o.getNomeFuncionarioAtendeu().equalsIgnoreCase(nomeBusca)) {
                                        funcionarioRelacionado = true;
                                    }
                                    if (o.getNomeFuncionarioAcompanhou() != null && o.getNomeFuncionarioAcompanhou().equalsIgnoreCase(nomeBusca)) {
                                        funcionarioRelacionado = true;
                                    }

                                    //se o funcionário estiver relacionado a essa ocorrência
                                    if (funcionarioRelacionado) {
                                        encontrouFunc = true;
                                        System.out.println("\n--- Ocorrência Relacionada ---");
                                        System.out.println("ID: " + o.getIdOcorrencia());
                                        System.out.println("Data: " + o.getData());
                                        System.out.println("Local: " + o.getLocal());
                                        System.out.println("Tipo: " + o.getTipo());
                                        System.out.println("Gravidade: " + o.getGravidade());
                                        System.out.println("Recebeu: " + o.getNomeFuncionarioRecebeu());
                                        System.out.println("Atendeu: " + o.getNomeFuncionarioAtendeu());
                                        System.out.println("Acompanhou: " + o.getNomeFuncionarioAcompanhou());
                                        System.out.println("-----------------------------\n");
                                    }
                                }

                                //caso não esteja
                                if (!encontrouFunc) {
                                    System.out.println("Nenhuma ocorrência encontrada para o funcionário informado.");
                                }
                                break;
                            case 2:
                                sc.nextLine(); //limpar buffer
                                System.out.println("Digite o mês para consultar (ex: Janeiro, Fevereiro, etc.):");
                                
                                //formata o input do usuário, remove espaços em brancos e passa para minúscula
                                String mesBusca = sc.nextLine().trim().toLowerCase();

                                //mapeia o nome do mês para o número correspondente
                                Map<String, Integer> mesesMap = new HashMap<>();
                                mesesMap.put("janeiro", 1);
                                mesesMap.put("fevereiro", 2);
                                mesesMap.put("março", 3);
                                mesesMap.put("abril", 4);
                                mesesMap.put("maio", 5);
                                mesesMap.put("junho", 6);
                                mesesMap.put("julho", 7);
                                mesesMap.put("agosto", 8);
                                mesesMap.put("setembro", 9);
                                mesesMap.put("outubro", 10);
                                mesesMap.put("novembro", 11);
                                mesesMap.put("dezembro", 12);
                                
                                //variável que pega o número do mês correspondente ao nome digitado
                                Integer numeroMes = mesesMap.get(mesBusca);
                                
                                //se um número compativel não existir
                                if (numeroMes == null) {
                                    //erro
                                    System.out.println("Mês inválido. Tente novamente.");
                                    break;
                                }
                                
                                boolean achouMes = false;

                                //percorre todas as ocorrências cadastradas e filtra pelo mês
                                for (Ocorrencia o : ocorrencias) {
                                    //se houver uma ocorrência registrada no mês digitado
                                    if (o.getData().getMonthValue() == numeroMes) {
                                        achouMes = true;
                                        System.out.println("\n--- Ocorrência no Mês " + numeroMes + " ---");
                                        System.out.println("ID: " + o.getIdOcorrencia());
                                        System.out.println("Data: " + o.getData());
                                        System.out.println("Local: " + o.getLocal());
                                        System.out.println("Tipo: " + o.getTipo());
                                        System.out.println("Gravidade: " + o.getGravidade());
                                        System.out.println("Recebeu: " + o.getNomeFuncionarioRecebeu());
                                        System.out.println("Atendeu: " + o.getNomeFuncionarioAtendeu());
                                        System.out.println("Acompanhou: " + o.getNomeFuncionarioAcompanhou());
                                        System.out.println("-----------------------------\n");
                                    }
                                }

                                //caso não tenha encontrado nenhuma ocorrência no mês
                                if (!achouMes) {
                                    System.out.println("Nenhuma ocorrência encontrada no mês " + mesBusca + ".");
                                }

                                break;
                            case 3: 
                                sc.nextLine(); //limpar buffer
                                System.out.println("Digite o local para consultar as ocorrências (ex: Empresa Solutions, Loja Shopping, etc.):");
                                
                                //formata input
                                String localBusca = sc.nextLine().trim().toLowerCase();

                                boolean encontrouLocal = false;

                                //percorre todas as ocorrências e filtra pelo local
                                for (Ocorrencia o : ocorrencias) {
                                    //caso exista uma ocorrência no local digitado pelo usuário
                                    if (o.getLocal().toLowerCase().contains(localBusca)) {
                                        encontrouLocal = true;
                                        System.out.println("\n--- Ocorrência no Local: " + o.getLocal() + " ---");
                                        System.out.println("ID: " + o.getIdOcorrencia());
                                        System.out.println("Data: " + o.getData());
                                        System.out.println("Tipo: " + o.getTipo());
                                        System.out.println("Gravidade: " + o.getGravidade());
                                        System.out.println("Recebeu: " + o.getNomeFuncionarioRecebeu());
                                        System.out.println("Atendeu: " + o.getNomeFuncionarioAtendeu());
                                        System.out.println("Acompanhou: " + o.getNomeFuncionarioAcompanhou());
                                        System.out.println("-----------------------------\n");
                                    }
                                }

                                //se não tiver nenhuma ocorrência no local
                                if (!encontrouLocal) {
                                    System.out.println("Nenhuma ocorrência encontrada no local \"" + localBusca + "\".");
                                }

                                break;
                            case 4:
                                sc.nextLine();
                                System.out.println("Digite o tipo da ocorrência que deseja consultar (ex: Incêndio, Roubo, etc.):");
                                
                                //formata input do usuário
                                String tipoBusca = sc.nextLine().trim().toLowerCase();

                                boolean encontrouTipo = false;
                                
                                //percorre a lista de ocorrências
                                for (Ocorrencia o : ocorrencias) {
                                    //se houver uma ocorrência com o tipo que o usuário está procurando
                                    if (o.getTipo().toLowerCase().contains(tipoBusca)) {
                                        encontrouTipo = true;
                                        System.out.println("\n--- Ocorrência do Tipo: " + o.getTipo() + " ---");
                                        System.out.println("ID: " + o.getIdOcorrencia());
                                        System.out.println("Data: " + o.getData());
                                        System.out.println("Local: " + o.getLocal());
                                        System.out.println("Gravidade: " + o.getGravidade());
                                        System.out.println("Recebeu: " + o.getNomeFuncionarioRecebeu());
                                        System.out.println("Atendeu: " + o.getNomeFuncionarioAtendeu());
                                        System.out.println("Acompanhou: " + o.getNomeFuncionarioAcompanhou());
                                        System.out.println("------------------------------------------");
                                    }
                                }
                                
                                //caso não haja
                                if (!encontrouTipo) {
                                    System.out.println("Nenhuma ocorrência encontrada para o tipo \"" + tipoBusca + "\".");
                                }

                                break;
                            case 5: 
                                System.out.println("Digite o nível de gravidade (1 a 10) que deseja consultar:");
                                int gravidadeBusca = sc.nextInt();
                                sc.nextLine();

                                boolean encontrouGravidade = false;
                                
                                //percorre lista de ocorrências
                                for (Ocorrencia o : ocorrencias) {
                                    //se houver uma ocorrência com a gravidade inserida pelo usuário
                                    if (o.getGravidade() == gravidadeBusca) {
                                        encontrouGravidade = true;
                                        System.out.println("\n--- Ocorrência com Gravidade: " + gravidadeBusca + " ---");
                                        System.out.println("ID: " + o.getIdOcorrencia());
                                        System.out.println("Data: " + o.getData());
                                        System.out.println("Local: " + o.getLocal());
                                        System.out.println("Tipo: " + o.getTipo());
                                        System.out.println("Recebeu: " + o.getNomeFuncionarioRecebeu());
                                        System.out.println("Atendeu: " + o.getNomeFuncionarioAtendeu());
                                        System.out.println("Acompanhou: " + o.getNomeFuncionarioAcompanhou());
                                        System.out.println("------------------------------------------");
                                    }
                                }
                                
                                //se não houver
                                if (!encontrouGravidade) {
                                    System.out.println("Nenhuma ocorrência encontrada com gravidade " + gravidadeBusca + ".");
                                }

                                break;
                            case 6:
                                //opção para voltar ao menu principal
                                System.out.println("voltar");
                                subMenuRelatorio = false;
                                break;
                            default:
                                //erro se opção inválida
                                System.out.println("Opção Inválida. Tente Novamente: ");
                        }
                    }
                    break;
                    
                case 4:
                    //opção de finalizar o programa
                    System.out.println("Programa Encerrado.");
                    System.exit(0);
                    break;
                    
                default:
                    //erro se opção inválida
                    System.out.println("Opção Inválida. Tente Novamente: ");
            }
        }
        
    }
}
