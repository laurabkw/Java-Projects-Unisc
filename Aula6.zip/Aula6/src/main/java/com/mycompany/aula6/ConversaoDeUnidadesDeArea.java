/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula6;

/**
 *
 * @author ADMIN
 */
public class ConversaoDeUnidadesDeArea {
    private static float metroQuadrado = 8250;
    private static float peQuadrado;
    private static float centimetroQuadrado;
    //private static float milhaQuadrada;
    private static float acre;
    
    public static float calcPesQuad(){
        peQuadrado = (float) 10.76;
        return metroQuadrado * peQuadrado;
    }
    
    /*
    public static float calcMilhaQuad(){
        milhaQuadrada = (float) 3.81;
        return metroQuadrado * milhaQuadrada;
    }
    */

    public static float calcCentQuad(){
        centimetroQuadrado = (float) 10000;
        return metroQuadrado * centimetroQuadrado;
    }
    
    public static float calcAcre(){
        acre = (float) 0.0002;
        return metroQuadrado * acre;
    }
}
