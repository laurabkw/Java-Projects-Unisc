/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula6;

/**
 *
 * @author ADMIN
 */
public class Distancia {
    private static float km;
    private static float milha;
    private static float pes;
    
    public static float calcMilha(){
        km = 382000;
        milha = (float) 0.62;
        return (km*milha)/2;
    }
    
    public static float calcPes(){
        km = 382000;
        pes = (float) 3280.84;
        return (km*pes)/2;
    }
}
