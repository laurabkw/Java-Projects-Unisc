/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula6;

/**
 *
 * @author ADMIN
 */
public class Aula6 {

    public static void main(String[] args) {
        //Exercício 1
        System.out.println("Exercício 1");
        System.out.println("Média em Milhas: "+ Distancia.calcPes());
        System.out.println("Média em Pés: " + Distancia.calcPes());
        System.out.println("\n");
        
        //Exercício 2
        System.out.println("Exercício 2");
        System.out.println("Área em Pés Quadrados: "+ ConversaoDeUnidadesDeArea.calcPesQuad());
        System.out.println("Área em Centímetros Quadrados: "+ConversaoDeUnidadesDeArea.calcCentQuad());
        System.out.println("Área em Acres: "+ConversaoDeUnidadesDeArea.calcAcre());
        System.out.println("\n");
        
        //Exercício 3
        System.out.println("Exercício 3");
        System.out.println("Soma 2 Inteiros: " + Calculo.soma_2_int() + " | Soma 3 Inteiros: " + Calculo.soma_3_int() + 
                " | Soma 4 Inteiros: " + Calculo.soma_4_int() + " | Soma 5 Inteiros: " + Calculo.soma_5_int());
        
        System.out.println("Média 2 Inteiros: " + Calculo.media_2_int() + " | Média 3 Inteiros: " + Calculo.media_3_int() + 
                " | Média 4 Inteiros: " + Calculo.media_4_int() + " | Média 5 Inteiros: " + Calculo.media_5_int());
        
        System.out.println("Soma 2 Floats: " + Calculo.soma_2_float() + " | Soma 3 Floats: " + Calculo.soma_3_float() + 
                " | Soma 4 Floats: " + Calculo.soma_4_float() + " | Soma 5 Floats: " + Calculo.soma_5_float());
        
        System.out.println("Média 2 Floats: " + Calculo.media_2_float() + " | Média 3 Floats: " + Calculo.media_3_float() + 
                " | Média 4 Floats: " + Calculo.media_4_float() + " | Média 5 Floats: " + Calculo.media_5_float());
        System.out.println("\n");
        
        //Exercício 4
        System.out.println("Exercício 4");
        Calculo2 obj = new Calculo2();
        System.out.println("Soma 2 Inteiros: " + obj.soma(10, 20));
        System.out.println("Soma 3 Inteiros: " + obj.soma(10, 20, 30));
        System.out.println("Soma 4 Inteiros: " + obj.soma(10, 20, 30, 40));
        System.out.println("Soma 5 Inteiros: " + obj.soma(10, 20, 30, 40, 50));
        System.out.println("Média 2 Inteiros: " + obj.media(10, 20));
        System.out.println("Média 3 Inteiros: " + obj.media(10, 20, 30));
        System.out.println("Média 4 Inteiros: " + obj.media(10, 20, 30, 40));
        System.out.println("Média 5 Inteiros: " + obj.media(10, 20, 30, 40, 50));
        System.out.println("\nSoma 2 Floats: " + obj.soma(10, 20));
        System.out.println("Soma 3 Floats: " + obj.soma(10, 20, 30));
        System.out.println("Soma 4 Floats: " + obj.soma(10, 20, 30, 40));
        System.out.println("Soma 5 Floats: " + obj.soma(10, 20, 30, 40, 50));
        System.out.println("Média 2 Floats: " + obj.media(10, 20));
        System.out.println("Média 3 Floats: " + obj.media(10, 20, 30));
        System.out.println("Média 4 Floats: " + obj.media(10, 20, 30, 40));
        System.out.println("Média 5 Floats: " + obj.media(10, 20, 30, 40, 50));
    }
}
