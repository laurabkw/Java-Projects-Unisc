/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula6;

/**
 *
 * @author ADMIN
 */
public class Calculo2 {
    private static int intA;
    private static int intB;
    private static int intC;
    private static int intD;
    private static int intE;
    
    private static float floatA;
    private static float floatB;
    private static float floatC;
    private static float floatD;
    private static float floatE;
    
    public int soma(int intA, int intB){
        return intA + intB;
    }
    
    public int soma(int intA, int intB, int intC){
        return intA + intB + intC;
    }
    
    public int soma(int intA, int intB, int intC, int intD){
        return intA + intB + intC + intD;
    }
    
    public int soma(int intA, int intB, int intC, int intD, int intE){
        return intA + intB + intC + intD + intE;
    }
    
    public float soma(float floatA, float floatB){
        return floatA + floatB;
    }
    
    public float soma(float floatA, float floatB, float floatC){
        return floatA + floatB + floatC;
    }
    
    public float soma(float floatA, float floatB, float floatC, float floatD){
        return floatA + floatB + floatC + floatD;
    }
    
    public float soma(float floatA, float floatB, float floatC, float floatD, float floatE){
        return floatA + floatB + floatC + floatD + floatE;
    }
    
    public int media(int intA, int intB){
        return (intA + intB)/2;
    }
    
    public int media(int intA, int intB, int intC){
        return (intA + intB + intC)/3;
    }
    
    public int media(int intA, int intB, int intC, int intD){
        return (intA + intB + intC + intD)/4;
    }
    
    public int media(int intA, int intB, int intC, int intD, int intE){
        return (intA + intB + intC + intD + intE)/5;
    }
    
    public float media(float floatA, float floatB){
        return (floatA + floatB)/2;
    }
    
    public float media(float floatA, float floatB, float floatC){
        return (floatA + floatB + floatC)/3;
    }
    
    public float media(float floatA, float floatB, float floatC, float floatD){
        return (floatA + floatB + floatC + floatD)/4;
    }
    
    public float media(float floatA, float floatB, float floatC, float floatD, float floatE){
        return (floatA + floatB + floatC + floatD + floatE)/5;
    }
}
