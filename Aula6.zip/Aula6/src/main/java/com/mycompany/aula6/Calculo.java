/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula6;

/**
 *
 * @author ADMIN
 */
public class Calculo {
    private static int intA = 10;
    private static int intB = 20;
    private static int intC = 30;
    private static int intD = 40;
    private static int intE = 50;
    
    private static float floatA = 10;
    private static float floatB = 20;
    private static float floatC = 30;
    private static float floatD = 40;
    private static float floatE = 50;
    
    public static int soma_2_int(){
        return intA + intB;
    }
    
    public static int soma_3_int(){
        return intA + intB + intC;
    }
    
    public static int soma_4_int(){
        return intA + intB + intC + intD;
    }
    
    public static int soma_5_int(){
        return intA + intB + intC + intD + intE;
    }
    
    public static int media_2_int(){
        return (intA + intB)/2;
    }
    
    public static int media_3_int(){
        return (intA + intB + intC)/3;
    }
    
    public static int media_4_int(){
        return (intA + intB + intC + intD)/4;
    }
    
    public static int media_5_int(){
        return (intA + intB + intC + intD + intE)/5;
    }
    
    public static float soma_2_float(){
        return floatA + floatB;
    }
    
    public static float soma_3_float(){
        return floatA + floatB + floatC;
    }
    
    public static float soma_4_float(){
        return floatA + floatB + floatC + floatD;
    }
    
    public static float soma_5_float(){
        return floatA + floatB + floatC + floatD + floatE;
    }
    
    public static float media_2_float(){
        return (floatA + floatB)/2;
    }
    
    public static float media_3_float(){
        return (floatA + floatB + floatC)/3;
    }
    
    public static float media_4_float(){
        return (floatA + floatB + floatC + floatD)/4;
    }
    
    public static float media_5_float(){
        return (floatA + floatB + floatC + floatD + floatE)/5;
    }
}
