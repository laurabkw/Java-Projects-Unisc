/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exerc2_aula3;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;
public class Documento {
    String nome;
    String extensao;
    int tamanhoDoc;
    
    Documento(String nome, String extensao, int tamanhoDoc){
        this.nome = nome;
        this.extensao = extensao;
        this.tamanhoDoc = tamanhoDoc;
    }
    
    void maiorDocumento(Documento[] vetorDocumentos){
        //maior recebe o vetor contendo todos os arquivos criados
        Documento maior = vetorDocumentos[0];
        
        //loop para percorrer todos os vetores
        for(int i = 1; i < vetorDocumentos.length - 1; i++){
            //se o proximo elemento do vetor tiver um tamanho de arquivo maior que o elemento atual
            if(vetorDocumentos[i + 1].tamanhoDoc > vetorDocumentos[i].tamanhoDoc){
                //maior recebe o próximo vetor
                maior = vetorDocumentos[i + 1];
            }
        }

        System.out.println("Maior arquivo: ");
        System.out.println("Nome: " + maior.nome + "." + maior.extensao);
        System.out.println("Tamanho: " + maior.tamanhoDoc);
    }
    
    int somaTamanhoDocumentos(Documento[] vetorDocumentos){
        //inicializado em 0
        int somarTamanhoDocumentos = 0;
        //loop para percorrer todos os elementos em vetorDocumentos
        for(int i = 0; i < vetorDocumentos.length; i++){
            //variável recebe o tamanho do arquivo do elemento + a própria variável
            somarTamanhoDocumentos = vetorDocumentos[i].tamanhoDoc + somarTamanhoDocumentos;
        }
        
        //se não houver elementos no vetor, ou seja, nenhum arquivo foi criado
        if(somarTamanhoDocumentos == 0){
            //printa erro
            System.out.println("Algo deu errado, tente novamente.");
        }

        return somarTamanhoDocumentos;
    }
    
    int arquivosMesmaExtensao(Documento[] vetorDocumentos, String extensaoDoArquivo){
        int total = 0;
        
        //loop que percorre o vetor com os arquivos criados
        for(int i = 0; i < vetorDocumentos.length; i++){
            //se a extensao do elemento for igual à extensão do arquivo
            if(vetorDocumentos[i].extensao.equals(extensaoDoArquivo)){
                //incrementa no número total de arquivos
                total = total + 1;
            }
        }

        return total;
    }
    
    void ler_dados(){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Informe o nome do arquivo: ");
        nome = sc.next();
        
        System.out.println("Informe a extensão do arquivo (ex: doc, exe, etc): ");
        extensao = sc.next();
        
        System.out.println("Informe o tamanho do arquivo:");
        tamanhoDoc = sc.nextInt();
        while(tamanhoDoc < 0){
            System.out.println("Valor inválido. Tente novamente:");
            tamanhoDoc = sc.nextInt();
        }
    }
 
    void mostrar_dados(){
        int unidadeByte = tamanhoDoc;
        int unidadeKbyte = unidadeByte / 1000;
        System.out.println("Nome do arquivo: "+ nome + "." + extensao);
        if(tamanhoDoc < 1000 && tamanhoDoc > 0){
            System.out.println("Tamanho do arquivo: "+ tamanhoDoc + "B");
        }
        else{
            System.out.println("Tamanho do arquivo: "+ unidadeKbyte + "KB");
        }
    }
   
}

