/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exerc1_aula3;

/**
 *
 * @author m154104
 */
import java.util.Scanner;
public class Veiculo {
    String placa;
    String modelo;
    String fabricante;
    int km;
    int anofab;
    
    void def_dados(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Informe o número da placa:");
        placa = sc.next();
        
        System.out.println("Informe o modelo:");
        modelo = sc.next();
        
        System.out.println("Informe o fabricante:");
        fabricante = sc.next();
        
        System.out.println("Informe a quilometragem:");
        km = sc.nextInt();
        while(km <=0){
            km = sc.nextInt();
            System.out.println("Valor inválido. Tente novamente:");
        }
        
        System.out.println("Informe o ano de fabricação:");
        anofab = sc.nextInt();
        while(anofab < 1950 || anofab > 2024){
            System.out.println("Valor inválido. Tente novamente: ");
            anofab = sc.nextInt();
        }
        System.out.println("-----------------------//-----------------------");
    }
    
    void mostrar_dados(){
        System.out.println("Placa do veiculo: "+ placa);
        System.out.println("Modelo do veiculo: "+ modelo);
        System.out.println("Fabricante do veiculo: "+ fabricante);
        System.out.println("Quilometragem do veiculo: "+ km);
        System.out.println("Ano de fabricação do veiculo: "+ anofab);
    }
    
    int aumentar_km(int vkmadic){
        km = km + vkmadic;
        return km;
    }
    
    int ret_km(){
        return km;
    }
    
    int ret_ano(){
        return anofab;
    }
}
