/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exerc1_aula3;

/**
 *
 * @author m154104
 */
import java.util.Scanner;
public class Exerc1_aula3 {

    public static void main(String[] args) {
        int numVeiculos = 3;
        Veiculo[] veiculos;
        veiculos = new Veiculo[numVeiculos];
        
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < numVeiculos; i++){
            veiculos[i] = new Veiculo();
            veiculos[i].def_dados();
            veiculos[i].mostrar_dados();
            
            System.out.println("Informe o valor a ser incrementado:");
            int vkmadic = sc.nextInt();
            System.out.println(veiculos[i].aumentar_km(vkmadic));
            
            System.out.println(veiculos[i].ret_km());
            System.out.println("Ano de fabricação: "+veiculos[i].ret_ano());
        }
        if(veiculos[0].ret_km() > veiculos[1].ret_km() && veiculos[0].ret_km() > veiculos[2].ret_km()){
            System.out.println("Maior km: "+veiculos[0].ret_km());
        }
        else if(veiculos[1].ret_km() > veiculos[0].ret_km() && veiculos[1].ret_km() > veiculos[2].ret_km()){
            System.out.println("Maior km: "+veiculos[1].ret_km());
        }
        else{
            System.out.println("Maior km: "+veiculos[2].ret_km());
        }
        
        if(veiculos[0].ret_km() < veiculos[1].ret_km() && veiculos[0].ret_km() < veiculos[2].ret_km()){
            System.out.println("Menor km: "+veiculos[0].ret_km());
            System.out.println("Placa do veiculo: "+ veiculos[0].placa);
            System.out.println("Modelo do veiculo: "+ veiculos[0].modelo);
            System.out.println("Fabricante do veiculo: "+ veiculos[0].fabricante);
            System.out.println("Quilometragem do veiculo: "+ veiculos[0].km);
            System.out.println("Ano de fabricação do veiculo: "+ veiculos[0].anofab);
        }
        else if(veiculos[1].ret_km() < veiculos[0].ret_km() && veiculos[1].ret_km() < veiculos[2].ret_km()){
            System.out.println("Menor km: "+veiculos[1].ret_km());
            System.out.println("Placa do veiculo: "+ veiculos[1].placa);
            System.out.println("Modelo do veiculo: "+ veiculos[1].modelo);
            System.out.println("Fabricante do veiculo: "+ veiculos[1].fabricante);
            System.out.println("Quilometragem do veiculo: "+ veiculos[1].km);
            System.out.println("Ano de fabricação do veiculo: "+ veiculos[1].anofab);
        }
        else{
            System.out.println("Menor km: "+veiculos[2].ret_km());
            System.out.println("Placa do veiculo: "+ veiculos[2].placa);
            System.out.println("Modelo do veiculo: "+ veiculos[2].modelo);
            System.out.println("Fabricante do veiculo: "+ veiculos[2].fabricante);
            System.out.println("Quilometragem do veiculo: "+ veiculos[2].km);
            System.out.println("Ano de fabricação do veiculo: "+ veiculos[2].anofab);
        }
    }
}
