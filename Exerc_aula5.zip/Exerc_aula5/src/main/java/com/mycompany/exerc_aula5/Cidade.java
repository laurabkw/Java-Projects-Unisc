/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exerc_aula5;

/**
 *
 * @author ADMIN
 */
public class Cidade {
    //métodos get e set
    //validação de dados dentro da classe
    //string nome, int populacao, string siglaestado, float area
    private String nome;
    private int populacao;
    private String siglaestado;
    private float area;
    
    public Cidade(){
        nome = "";
        populacao = 0;
        siglaestado = "";
        area = 0;
    }
    
    public Cidade(String nome, int populacao, String siglaestado, float area){
        setNome(nome);
        setPopulacao(populacao);
        setSiglaestado(siglaestado);
        setArea(area);
    }
    
    public String getNome(){
        return nome;
    }
    
    public int getPopulacao(){
        return populacao;
    }
    
    public String getSiglaestado(){
        return siglaestado;
    }
    
    public float getArea(){
        return area;
    }
    
    //métodos set
    public void setNome(String nome){
        if(nome.equals("")){
            this.nome = "";
        }
        else{
            this.nome=nome;
        }
    }
    
    public void setPopulacao(int populacao){
        if(populacao<=0){
            this.populacao = 0;
        }
        else{
            this.populacao = populacao;
        }
    }
    
    public void setSiglaestado(String siglaestado){
        if((siglaestado.equals("")) || (siglaestado.length()>2) || (siglaestado.length() <= 1)){
            this.siglaestado = "";
        }
        else{
            this.siglaestado=siglaestado;
        }
    }
    
    public void setArea(float area){
        if(area<=0){
            this.area = 0;
        }
        else{
            this.area = area;
        }
    }
}
