/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exerc_aula5;
import java.util.Scanner;
/**
 *
 * @author ADMIN
 */
public class Exerc_aula5 {

    public static void main(String[] args) {
        //validação de dados no programa principal
        //criar array para guardar essas várias cidades
        //perguntar qual estado quer filtrar e mostrar todas as cidades desse estado
        //relatório final: número de cidades, população média, cidade com maior população e seu nome
        Scanner sc = new Scanner(System.in);
        
        String nome, siglaestado;
        int populacao;
        float area;
        
        System.out.println("Digite o número de cidades que deseja criar: ");
        int numCidades = sc.nextInt();
        Cidade[] cidades = new Cidade[numCidades];
        for(int i = 0; i < numCidades;i++){
            cidades[i] = new Cidade();
            System.out.println("Nome: ");
            nome=sc.next();
            while(nome.equals("")){
                System.out.println("Valor Inválido. Tente Novamente: ");
                nome=sc.next();
            }
            cidades[i].setNome(nome);
            
            System.out.println("População: ");
            populacao=sc.nextInt();
            while(populacao<0){
                System.out.println("Valor Inválido. Tente Novamente: ");
                populacao=sc.nextInt();
            }
            cidades[i].setPopulacao(populacao);
            
            System.out.println("Sigla do Estado: ");
            siglaestado=sc.next();
            while((siglaestado.equals("")) || (siglaestado.length() > 2) || (siglaestado.length() <= 1)){
                System.out.println("Valor Inválido. Tente Novamente: ");
                siglaestado=sc.next();
            }
            cidades[i].setSiglaestado(siglaestado);
            
            System.out.println("Área: ");
            area=sc.nextFloat();
            while(area<=0){
                System.out.println("Valor Inválido. Tente Novamente: ");
                area=sc.nextFloat();
            }
            cidades[i].setArea(area);
        }
        
        //perguntar estado e mostrar todas as cidades desse estado
        System.out.println("Insira a sigla do estado que deseja pesquisar: ");
        //recebe a sigla digitada pelo usuário
        String procuraSigla = sc.next();
        //loop que percorre todas as cidades criadas
        for(int i = 0; i < numCidades; i++){
            //se o dado inserido pelo usuário for igual ao contido em i
            if(procuraSigla.equals(cidades[i].getSiglaestado())){
                //mostra os dados da(s) cidade(s) correspondentes
                System.out.println("\nNome: " + cidades[i].getNome());
                System.out.println("População: " + cidades[i].getPopulacao());
                System.out.println("Area: " + cidades[i].getArea());
                System.out.println("\n");
            }
        }
        
        //relatório final: número de cidades, população média, cidade com maior população e seu nome
        System.out.println("Relatório Final: ");
        System.out.println("Número de Cidades: " + numCidades);
        
        //soma e media iniciadas em 0
        float soma = 0;
        float media = 0;
        //percorre todas as cidades, pega a população de cada uma e soma
        for(int i = 0; i < numCidades; i++){
            soma = soma + cidades[i].getPopulacao();
        }
        //pega a soma de todas as populações e divide pelo número de cidades criadas
        media = soma/numCidades;
        System.out.println("População Média: " + media);
        
        //recebe o nome da primeiro cidade do array
        String nomeMaiorCidade = cidades[0].getNome();
        //recebe a população da primeira cidade do array
        int maior = cidades[0].getPopulacao();
        //loop que percorre todas as cidades
        for(int i = 0; i < numCidades; i++){
            //se a população da cidade em i for maior
            if(cidades[i].getPopulacao() > maior){
                //maior recebe a cidade com mais população
                maior = cidades[i].getPopulacao();
                //recebe o nome da cidade com mais população
                nomeMaiorCidade = cidades[i].getNome();
            }
        }

        System.out.println("Maior Cidade: " + nomeMaiorCidade + "   ||   População: " + maior); //colocar nome e população na mesma linha
        
    }
}
